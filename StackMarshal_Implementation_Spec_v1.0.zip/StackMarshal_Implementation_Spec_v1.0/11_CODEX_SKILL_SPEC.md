# 11. Codex Skill仕様

## 11.1 Skill名

`stackmarshal`

## 11.2 Frontmatter

- name: stackmarshal
- description: 1024文字以下
- 明示名指しのみという条件をdescriptionへ入れる
- 通常の実装依頼から推測発火しない
- 多言語の例を簡潔に含める

## 11.3 SKILL.md

500行以下を目標にする。
Core workflowのみを置き、詳細はreferencesへ分離。

必須セクション:

1. Invocation gate
2. Mode inference
3. Initialize run
4. Research gate
5. Capability map
6. Discovery
7. Trust and acquisition
8. Freeze
9. Build
10. Verify
11. Stop harness
12. Checkpoint
13. Output contract

## 11.4 References

- workflow.md
- research-policy.md
- capability-policy.md
- acquisition-policy.md
- security-policy.md
- stop-policy.md
- checkpoint-policy.md
- output-contract.md
- adapter-selection.md

## 11.5 Scripts

- init_run.py
- validate_state.py
- check_budget.py
- score_candidates.py
- fingerprint_failure.py
- evaluate_progress.py
- create_checkpoint.py
- resolve_resume.py
- verify_lock.py
- quick_validate.py

## 11.6 Progressive Disclosure

常時コンテキスト:
- name
- description

発火後:
- SKILL.mdのみ

必要時:
- 各reference
- スクリプトは実行優先
- 大量データはファイル化し、要約だけコンテキストへ

## 11.7 Triggerテスト

- 明示日本語 build
- 明示英語 build
- 明示中国語 build
- `$stackmarshal`
- 名前説明では非起動
- 類似名称では非起動
- README編集対象では非起動
- 大小文字差
- 全角スペース
