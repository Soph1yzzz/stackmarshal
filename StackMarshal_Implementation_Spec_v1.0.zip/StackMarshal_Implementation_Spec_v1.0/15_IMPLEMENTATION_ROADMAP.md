# 15. 実装ロードマップ

## Phase 0: Bootstrap

- repository
- license
- package layout
- CI
- schemas
- test harness

## Phase 1: Bounded State Core

- config
- state machine
- event log
- budget
- failure fingerprint
- progress
- checkpoint
- resume

Exit: 停止ハーネスだけで完全テスト可能。

## Phase 2: Codex Skill

- SKILL.md
- references
- scripts integration
- trigger tests
- multilingual examples

Exit: research mock workflowがCodexで発火。

## Phase 3: Research

- GitHub adapters
- candidate metadata
- evidence bundle
- caching
- source provenance

Exit: 上限内で類似OSS比較レポート。

## Phase 4: Capability Discovery

- local skills
- MCP config
- Codex plugins
- package registries
- candidate classification
- scoring

Exit: Capability Mapと候補決定。

## Phase 5: Safe Acquisition

- inspection
- isolated PoC
- receipt
- lock
- rollback
- approval gates

Exit: project-local候補を安全導入。

## Phase 6: Build Integration

- architecture freeze
- task graph
- Codex execution contract
- verification loop
- research reentry gate

Exit: 小規模OSSをbuildモードで完成。

## Phase 7: Hardening

- adversarial tests
- Windows
- docs
- release
- forward tests
- name recheck

Exit: v1.0。
