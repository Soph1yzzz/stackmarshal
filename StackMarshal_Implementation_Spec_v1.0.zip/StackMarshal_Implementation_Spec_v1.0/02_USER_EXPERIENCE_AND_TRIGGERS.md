# 2. ユーザー体験と起動規約

## 2.1 標準利用

```text
StackMarshalを使って実装して。

このリポジトリにWindows向けランチャーを追加してください。
初めて使う人がREADMEだけで導入できること。
```

期待挙動:

1. StackMarshalの明示使用を認識
2. `build`モードと推論
3. 依頼言語で応答
4. 要件、予算、停止条件を短く提示
5. 調査・能力獲得・設計・実装・検証を開始
6. COMPLETEまたは正式停止状態で終了

## 2.2 多言語

名前はASCIIの `StackMarshal` を正式表記にする。
全角、大小文字、自然な助詞を許容する。

認識例:

- StackMarshalを使って
- stackmarshalで
- STACKMARSHALを使用
- Use StackMarshal
- with StackMarshal
- 使用 StackMarshal
- 用 StackMarshal
- StackMarshal로
- Utilise StackMarshal

## 2.3 モード推論

- 「調べて」「比較して」 -> research
- 「準備して」「計画まで」 -> prepare
- 「実装して」「作って」「修正して」 -> build
- 「続きから」「再開して」 -> resume

曖昧な場合は、ユーザーの最終行動目的を優先する。
実装を求めていればbuildとする。

## 2.4 明示コマンド

```text
$stackmarshal research
$stackmarshal prepare
$stackmarshal build
$stackmarshal resume
```

オプション:

```text
--budget quick|standard|deep
--mode advisory|guarded|autonomous
--no-acquire
--local-only
--checkpoint-on-complete
```

## 2.5 誤発火防止

起動には以下の両方が必要。

1. 名称の明示
2. 名称が「使用する仕組み」として文法的・意味的に指定されている

名称への言及、説明、比較、編集対象としての出現だけでは起動しない。

## 2.6 Codex互換性

Codexのバージョンによって、plain-text名指しと明示Skill injectionの挙動が異なる可能性がある。

実装方針:

- `$stackmarshal` を最も確実な入口として維持
- 通常の自然言語名指しもdescriptionで発火
- `policy.allow_implicit_invocation: false` が、plain-text明示呼び出しを
  信頼できるホストでは有効化
- それ以外ではimplicit invocationを許可しつつ、
  descriptionとruntime gateで「明示名指しのみ」を強制
