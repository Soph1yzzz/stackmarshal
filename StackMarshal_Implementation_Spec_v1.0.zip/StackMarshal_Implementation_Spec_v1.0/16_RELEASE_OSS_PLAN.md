# 16. OSS公開計画

## 16.1 Repository

推奨:

```text
<owner>/stackmarshal
```

`.com`が取得できない場合でもGitHub名を優先。
必要なら`stackmarshal-ai`をfallbackにする。

## 16.2 License

Apache-2.0推奨。
理由:
- 商用利用可能
- 明示的なpatent grant
- コントリビューターと企業利用に向く

Skill個別配布にもLICENSEを同梱。

## 16.3 Release Assets

- stackmarshal-skill-v1.0.0.zip
- stackmarshal-source-v1.0.0.tar.gz
- SHA256SUMS
- SBOM
- provenance attestation where practical

## 16.4 Install

README例:

```text
$skill-installer install https://github.com/<owner>/stackmarshal/tree/main/skills/stackmarshal
```

Codex再起動後:

```text
StackMarshalを使って実装して。
```

## 16.5 README

英語を主、README.ja.mdを用意。

冒頭で説明:

- What
- Why
- How it stops
- Security
- Example
- Install
- Limitations

「90% token削減」など未検証数値を宣伝しない。
「無駄な再実装と無制限ループを抑える」と表現する。

## 16.6 GitHub運用

- Issues templates
- security policy
- discussions
- good first issue
- adapter requests
- RFC process
- changelog
- semantic versioning

## 16.7 Name Release Gate

公開前に再確認:

- GitHub exact name
- npm
- PyPI
- crates
- domain
- USPTO
- WIPO
- EUIPO
- J-PlatPat
- general web
- social handles where important

問題発生時はブランド定数、package名、state directory migrationを使って改名する。
