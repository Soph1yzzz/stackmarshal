# 8. 停止条件ハーネス

## 8.1 目的

完走を無理に保証すると、調査、再設計、再実装が無限に続く。
StackMarshalは「有限収束」を製品の中心に置く。

## 8.2 観測可能な上限

標準プロファイル:

```toml
[limits]
research_rounds = 3
broad_candidates = 12
deep_review_candidates = 3
repository_clones = 1
acquisition_attempts_per_capability = 2
research_reentries = 1
architecture_replans = 2
attempts_per_task = 3
same_failure_repetitions = 2
stagnation_cycles = 2
scope_additions = 5
tool_calls = 120
changed_files_soft_limit = 80
```

ホストが信頼できるtoken usageを公開する場合だけtoken ceilingを追加する。
token数だけに依存してはならない。

## 8.3 予算プロファイル

### quick
- 小規模
- research 1 round
- deep candidates 1
- replan 1
- attempts 2

### standard
上記標準値。

### deep
- 明示指定時のみ
- 上限は増やすが無制限にしない
- 高リスク領域ではguarded必須

## 8.4 進捗

各cycleで最低1つ改善が必要。

- 完了acceptance criteria増加
- 通過テスト増加
- 未完了タスク減少
- ブロッカー解消
- 不確実性低下
- 根本原因の具体化
- 安全な代替候補確定

二cycle改善なし:
1. 1回だけREPLAN
2. その後も改善なしならSTAGNATED

## 8.5 Failure Fingerprint

次を正規化してfingerprintを作る。

- command category
- error category
- target
- normalized message
- suspected root cause
- environment

同一fingerprintが上限に達したら同じ手段を繰り返さない。

## 8.6 Scope Drift

新規作業を追加できる条件:

- 必須条件達成に不可欠
- セキュリティに不可欠
- build成立に不可欠
- 既存コードを壊さないため不可欠

それ以外は`future-work.md`へ送る。

## 8.7 停止順位

1. Safety
2. User cancellation
3. Approval
4. Invalid state
5. Budget
6. Repeated failure
7. Stagnation
8. Scope drift
9. External blocker

## 8.8 正式停止時の義務

- 状態をflush
- 差分を把握
- 破損した途中導入をrollback
- checkpoint生成
- next actionを1つに絞る
- 再試行禁止事項を記録
- resumeコマンドを表示
