# StackMarshal Checkpoint

- Run:
- Status:
- Stop reason:
- Project:
- Git HEAD:
- Mode:
- Current phase:
- Budget remaining:

## Goal

## Completed

## Mandatory criteria status

## Selected capabilities and dependencies

## Rejected candidates

## Failures and root causes

## Do not repeat

## Files changed

## Tests

## External approvals required

## Next single action

## Resume

```text
StackMarshalを使って続きから再開して。
```
