# Architecture Decision Record

- ID:
- Date:
- Status:
- Decision:

## Context

## Options

## Selected option

## Reasons

## Risks

## Rejected alternatives

## Verification

## Revisit conditions
