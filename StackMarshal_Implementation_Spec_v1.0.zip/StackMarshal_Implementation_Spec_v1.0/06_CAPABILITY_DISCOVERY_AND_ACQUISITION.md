# 6. 能力探索と獲得

## 6.1 Capability Map

各能力には以下を持たせる。

- id
- requirement_link
- description
- status
- criticality
- acquisition_options
- selected_option
- trust_level
- evidence
- verification
- fallback
- approval_class

## 6.2 候補カテゴリ

### Reference OSS
設計と失敗を学ぶ。導入対象とは限らない。

### Agent Skill
Codexの手順・知識・Workflowを増やす。

### MCP Server
外部ツールやデータへの操作能力を増やす。

### Codex Plugin
SkillとApp依存を含むWorkflowパッケージ。

### Application Library
作る製品の依存関係。

### External CLI
ビルド、監査、変換、デプロイ等に使う。

## 6.3 探索順序

1. 既存能力で解決可能か
2. プロジェクト内の既存実装
3. 既にインストール済みのSkill/MCP/Plugin
4. 公式・一次ソース
5. 有力OSS
6. 自作

## 6.4 スコア

100点満点:

- requirement_fit: 30
- maintenance_health: 15
- security_posture: 15
- architecture_quality: 10
- license_compatibility: 10
- platform_support: 10
- integration_cost: 5
- documentation: 5

失格:

- no_license
- archived
- incompatible_platform
- critical_known_vulnerability
- unapproved_secret_requirement
- suspicious_install_hook
- unreviewable_binary
- cannot_pin_version
- excessive_permissions

## 6.5 獲得深度

再帰深度は1。

StackMarshalが導入候補Skillの中から、さらに別Skillを無制限に探索することを禁止する。
候補の依存はmanifestとして列挙し、独立に評価する。

## 6.6 PoC

可能な順:

1. temporary directory
2. virtual environment
3. Git worktree
4. container

確認:

- install
- recognition
- claimed capability
- side effects
- network
- files changed
- uninstallation
- Windows/macOS/Linux compatibility
- rollback

## 6.7 導入承認

自動可:

- プロジェクトローカル
- バージョン固定
- no postinstall
- no secret
- no elevated permission
- reversible

承認必須:

- グローバルSkill/MCP/Plugin設定
- 外部バイナリ
- 秘密情報
- 課金
- 公開
- デプロイ
- ネットワーク公開
- 管理者権限
- ライセンス不明

## 6.8 LockとProvenance

必須:

- kind
- canonical id
- source URL
- registry
- version
- commit SHA
- content hash
- license
- permissions
- selected reason
- rejected alternatives
- verification result
