# Source Baseline

仕様作成時に確認した主要な一次・準一次情報。

- OpenAI Skills Catalog: skills are folders containing instructions, scripts, and resources.
- OpenAI Skill Creator: SKILL.md frontmatter name/description controls triggering;
  progressive disclosure and bounded context are recommended.
- OpenAI Skill Installer: GitHub directory URLからSkillを導入可能。
- OpenAI Codex repository context review policy: unbounded context injectionを禁止。
- OpenAI Codex issues: explicit-only skill routingはバージョン差があるため、
  `$stackmarshal` fallbackと自然言語runtime gateの両方が必要。
- OpenAI Codex Plugins documentation: Plugins can package Skills and approved Apps.
- GitHub exact repository search for three name candidates.
- npm and PyPI exact-name public search.
- ICANN RDAP as the authoritative domain-registration lookup method.

実装時は最新公式仕様を再確認すること。
