# 12. 補助CLI仕様

## 12.1 目的

LLM判断に向かない決定論的処理を担当する。
SkillはCLI無しでも読めるが、v1.0の正式動作では同梱Coreを利用する。

## 12.2 コマンド

```text
stackmarshal init
stackmarshal start --mode build --budget standard
stackmarshal state show
stackmarshal state transition <phase>
stackmarshal budget check
stackmarshal candidate score <file>
stackmarshal failure fingerprint <file>
stackmarshal progress evaluate
stackmarshal lock verify
stackmarshal checkpoint create
stackmarshal resume inspect
stackmarshal validate
stackmarshal report
```

## 12.3 出力

機械出力はJSON。
人間向け表示は標準エラーまたは`--human`で提供。
秘密情報を表示しない。

## 12.4 Exit Code

- 0 success
- 2 invalid input
- 3 invalid state
- 4 budget exhausted
- 5 approval required
- 6 unsafe
- 7 external blocked
- 8 checkpoint created
- 9 complete

## 12.5 Package

- distribution: `stackmarshal`が空いていれば使用
- fallback distribution: `stackmarshal-cli`
- import package: `stackmarshal`
- executable: `stackmarshal`

v1.0 Skill zipにはCore sourceを同梱する。
PyPI公開はRelease Gateを通過後。
