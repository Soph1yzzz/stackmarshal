# 17. 多言語戦略

## 17.1 原則

- ユーザーと同じ言語で応答
- 内部schema keyは英語固定
- ブランド名はASCII固定
- エラーコードは英語固定
- 人間向け説明は翻訳可能

## 17.2 Trigger

descriptionに大量の翻訳を詰めず、短い代表例を入れる。
名称＋使用動詞の意味をLLMに判定させる。

## 17.3 Prompt保存

元のユーザー文を保持しつつ、normalized intentを英語schemaへ格納する。
意味が変わる翻訳を禁止。

## 17.4 テスト言語

v1.0必須:
- English
- Japanese
- Simplified Chinese

追加:
- Korean
- Spanish
- German
- French

## 17.5 出力

コード、ファイル名、schemaは英語。
レポート本文はユーザー言語。
