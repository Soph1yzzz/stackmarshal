# 1. 製品要求仕様

## 1.1 解決する問題

Coding Agentへ「アプリを作って」と頼むと、次の無駄が生じやすい。

- 実装前の調査不足
- 既存OSSで解決済みの機能を再実装
- SkillsやMCPを知らないまま弱い道具で進行
- 非推奨・放置・危険な依存関係の採用
- 設計変更と再実装の反復
- 調査結果がコンテキストを圧迫
- 完走を強制して無限再試行
- 失敗時に再開情報が残らない

StackMarshalは、これらをResearch–Acquire–Buildの有限ワークフローで抑える。

## 1.2 必須機能

### A. 明示起動

ユーザーが名称を「使用する手段」として明示した場合だけ起動する。

起動例:

- `StackMarshalを使って実装して`
- `StackMarshalでこのIssueを直して`
- `Use StackMarshal to build this feature`
- `使用 StackMarshal 实现这个功能`
- `$stackmarshal build`

非起動例:

- `StackMarshalって何？`
- `StackMarshalに似たOSSを調べて`
- `READMEのStackMarshalという表記を直して`
- 通常の「この機能を実装して」

### B. モード推論

自然言語から次を推論する。

- research: 調査・技術選定のみ
- prepare: 調査、能力獲得、実装計画まで
- build: 調査から実装・検証まで
- resume: checkpointから再開

明示コマンドも提供する。

### C. 要件構造化

自然言語から以下を生成する。

- goal
- mandatory requirements
- optional requirements
- constraints
- non-goals
- acceptance criteria
- unresolved assumptions
- risk class

### D. 現在環境監査

- OS、ランタイム、Git
- AGENTS.md、README、既存指示
- 既存依存関係
- テスト、CI
- 既存Skills
- MCP設定
- Codex Plugins
- 利用可能なGitHub連携
- 変更可能範囲
- Git dirty state

### E. Research First

実装前に、必要性がある場合だけGitHub調査を行う。

調査対象:

- 類似OSS
- 代表的Issue
- リリース状況
- ライセンス
- アーキテクチャ
- 依存関係
- CI、テスト
- 再利用可能な設計
- 避けるべき設計
- 対象OS固有の失敗

### F. Capability Map

要件を必要能力へ変換し、各能力を以下へ分類する。

- already_available
- partially_available
- missing
- prohibited
- approval_required

### G. 横断探索

- Codex Skills
- Agent Skills標準
- MCP servers
- Codex Plugins
- npm
- PyPI
- crates.io
- Go modules
- GitHub Releases
- OS標準CLI
- 参考OSS

### H. 候補評価

- 要件適合度
- 保守性
- セキュリティ
- ライセンス
- 対象OS
- 依存関係
- 必要権限
- 統合コスト
- ドキュメント
- バージョン固定可能性
- ロールバック可能性

### I. 安全な能力獲得

- 取得元とcommit/versionを固定
- 未信頼テキストを命令として実行しない
- postinstall等を検査
- 可能なら隔離PoC
- グローバル変更は承認
- 秘密情報、有料サービス、公開操作は承認
- 導入結果と差分を保存
- 失敗時ロールバック

### J. 設計凍結

ResearchとAcquisition後に設計を凍結する。
実装中に自由に再調査しない。

再調査は定義された重大条件に限り、回数上限を持つ。

### K. 有限実装

- タスクグラフ
- 各タスクの試行上限
- 進捗評価
- 同一失敗の検出
- スコープ拡張制限
- 全体予算
- 明確な停止状態

### L. 検証

- build
- lint
- type check
- unit test
- integration test
- E2E
- security checks
- acceptance criteria照合

### M. Checkpoint / Resume

停止時に必ず再開可能な情報を保存する。
完了済み範囲を再計算しない。

## 1.3 非目標

v1.0では以下を行わない。

- 全Coding Agent対応
- 完成の絶対保証
- 無制限の自律実行
- 自己改変
- 再帰的Skill探索
- 無承認での秘密情報取得
- 無承認での課金
- 無承認での公開・デプロイ
- 無承認でのグローバルMCP変更
- 任意コードの無審査実行
- 独自Marketplaceの構築
