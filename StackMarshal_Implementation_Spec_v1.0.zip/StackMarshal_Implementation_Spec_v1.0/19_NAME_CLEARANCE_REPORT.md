# 19. 名称一次精査レポート

調査日: 2026-08-04

## 注意

これは公開情報に基づく一次スクリーニングであり、法律意見ではない。
商標の類否、指定商品・役務、地域別権利、未公開出願までは保証しない。

## ScoutSmith

### GitHub
完全一致リポジトリあり:
- `sumeru-26/ScoutSmith`

### npm / PyPI
公開検索で完全一致パッケージは確認できなかった。

### 一般検索
同名の人物・SNSハンドル等が複数存在。

### 判定
開発ツールとして重大な衝突とは限らないが、GitHub完全一致があるため落選。

## AtlasSmith

### GitHub
完全一致リポジトリは確認できなかった。

### npm / PyPI
公開検索で完全一致パッケージは確認できなかった。

### Domain
公開ドメイン一覧で `atlassmith.com` が登録済みとして掲載されている。

### 一般検索
Sketchfab、Flickr等に同名ハンドルあり。

### 判定
.com取得不可とみられ、第二候補の条件を満たさないため落選。

## StackMarshal

### GitHub
完全一致リポジトリは確認できなかった。

### npm / PyPI
公開検索で完全一致パッケージは確認できなかった。

### Trademark
検索エンジンから確認できるUSPTO/WIPO関連の完全一致結果は見つからなかった。

### Domain
主要検索で `stackmarshal.com` / `.dev` / `.io` の既存サービスは確認できなかった。
ただし、これは未登録を保証しない。リリース直前にICANN RDAPまたはRegistrarで
リアルタイム確認し、取得すること。

### 判定
3候補中、公開衝突が最も少ないため正式仮称として採用。

## 推奨取得

優先:
1. stackmarshal.com
2. stackmarshal.dev
3. stackmarshal.io

Fallback:
- stackmarshal.ai
- stackmarshal.tools
- stackmarshal.devを公式サイトにしてGitHubは`stackmarshal`

## Source Notes

- GitHub repository search
- npm public registry search
- PyPI search
- ICANN RDAP methodology
- USPTO/WIPO public-index search
- General web exact-match search

公開前に必ず再調査する。
