# 14. v1.0受け入れ条件

## 起動

- [ ] `StackMarshalを使って実装して`で発火
- [ ] `Use StackMarshal...`で発火
- [ ] `使用 StackMarshal...`で発火
- [ ] `$stackmarshal build`で発火
- [ ] 通常の実装依頼では非発火
- [ ] 名前の説明要求では非発火

## Workflow

- [ ] requirementsとacceptance criteriaを生成
- [ ] research gateを判定
- [ ] 類似OSSを上限内で調査
- [ ] Capability Mapを生成
- [ ] Skill/MCP/Plugin/library/CLIを区別
- [ ] 候補を採点
- [ ] provenanceを保存
- [ ] architecture freezeを生成
- [ ] task graphを生成
- [ ] buildモードで実装へ進む

## Safety

- [ ] README prompt injectionを実行しない
- [ ] postinstallを検出
- [ ] global changeで承認停止
- [ ] secret requirementで承認停止
- [ ] unpinned candidateを拒否または固定
- [ ] rollback receiptを保存
- [ ] self recursionを防止

## Stop Harness

- [ ] research上限
- [ ] tool call上限
- [ ] replan上限
- [ ] repeated failure停止
- [ ] stagnation停止
- [ ] scope drift停止
- [ ] budget exhausted停止
- [ ] すべての停止でcheckpoint生成

## Resume

- [ ] checkpoint schema検証
- [ ] 完了済み処理を再計算しない
- [ ] failure do-not-repeatを尊重
- [ ] project mismatchを拒否
- [ ] schema migrationテスト

## Distribution

- [ ] GitHubからSkill installerで導入可能
- [ ] restart後に認識
- [ ] Windows/macOS/Linuxで動作
- [ ] LICENSE、SECURITY、CONTRIBUTING
- [ ] Release zipとsha256
- [ ] 日本語・英語README
