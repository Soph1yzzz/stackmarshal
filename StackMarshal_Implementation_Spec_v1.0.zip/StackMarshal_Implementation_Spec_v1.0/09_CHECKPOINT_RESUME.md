# 9. CheckpointとResume

## 9.1 Checkpoint内容

- run id
- timestamp
- project identity
- git HEAD
- dirty state snapshot
- mode
- budget used / remaining
- completed phases
- current phase
- requirements
- acceptance status
- capability map
- selected and rejected candidates
- architecture decisions
- task states
- failure history
- files changed
- tests run
- stop reason
- next action
- do-not-repeat list
- resume command

## 9.2 Resume手順

1. checkpoint schema検証
2. 対象リポジトリidentity検証
3. Git HEADと差分確認
4. 完了済みタスクをskip
5. lock/provenance検証
6. 期限切れ外部情報だけ更新
7. remaining budget復元
8. current phaseから再開

## 9.3 再計算禁止

次は原則再利用。

- 完了済み環境監査
- commit SHAが同じ候補調査
- 失格候補
- PoC失敗
- 完了テスト
- 確定architecture decisions

更新条件:

- 対象コミット変更
- 依存バージョン変更
- checkpointが古い
- セキュリティ情報に更新
- ユーザー要件変更

## 9.4 互換性

checkpoint schemaにはversionを持たせる。
v1.x内はmigrationを提供する。
未知のfuture schemaを黙って読み込まない。
