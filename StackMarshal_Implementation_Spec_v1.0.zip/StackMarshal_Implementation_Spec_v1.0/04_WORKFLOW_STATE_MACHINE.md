# 4. ワークフロー状態機械

## 4.1 状態

- INVOCATION_CHECK
- INTENT_NORMALIZATION
- ENVIRONMENT_AUDIT
- RESEARCH_GATE
- LANDSCAPE_RESEARCH
- CAPABILITY_MAPPING
- CAPABILITY_DISCOVERY
- TRUST_EVALUATION
- ISOLATED_POC
- ARCHITECTURE_FREEZE
- TASK_GRAPH
- IMPLEMENTATION
- VERIFICATION
- REPLAN
- CHECKPOINTING
- COMPLETE
- STOPPED

## 4.2 終了状態

- COMPLETE
- CHECKPOINT_READY
- BUDGET_EXHAUSTED
- STAGNATED
- REPEATED_FAILURE
- APPROVAL_REQUIRED
- BLOCKED_EXTERNAL
- UNSAFE_DEPENDENCY
- SCOPE_DRIFT
- INVALID_STATE
- USER_CANCELLED

## 4.3 遷移規則

1. 明示起動に失敗した場合はSkillを終了し、通常応答へ戻す。
2. researchモードはARCHITECTURE_FREEZE後にレポートを出して終了。
3. prepareモードはTASK_GRAPH後に終了。
4. buildモードはIMPLEMENTATIONとVERIFICATIONへ進む。
5. resumeモードは最新の有効checkpointを検証して復元する。
6. REPLANは最大回数を超えたら停止。
7. RESEARCHへの再入場は重大条件に限り最大1回。
8. すべての状態遷移はevent logへ追記する。
9. 状態の巻き戻しは新イベントとして記録し、履歴を書き換えない。

## 4.4 再調査条件

許可:

- 採用依存が対象環境で実際に非互換
- PoCで能力不足が実証
- 設計前提がテストで反証
- Criticalなセキュリティ問題
- ライセンス不適合が判明

不許可:

- もっと格好いい構成を思いついた
- 別ライブラリの方が少し人気
- ついでに追加機能を作りたい
- 同一エラーの原因を調べず道具を交換したい

## 4.5 状態不変条件

- 予算カウンタは減らせない
- 採用候補にはprovenanceが必要
- Architecture Freeze後の変更にはDecision Recordが必要
- 完了済みタスクをresumeで再実行しない
- 停止時はcheckpoint生成を試みる
- 不正なstateでは実装を継続しない
