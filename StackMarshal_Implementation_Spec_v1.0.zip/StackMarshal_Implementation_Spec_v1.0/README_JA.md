# StackMarshal 実装仕様書 v1.0

このZIPは、別のCodexチャットが **StackMarshal** を設計判断からやり直さず、
OSSとして実装・試験・公開まで進めるための完全仕様書です。

StackMarshalは、ユーザーが明示的に名前を呼んだ場合だけ起動する
Codex向けの「調査・能力獲得・実装・検証」Skillです。

例:

```text
StackMarshalを使って実装して。
```

起動後は、いきなりコードを書かず、次を有限の予算内で行います。

1. 作りたいものと完成条件を理解する
2. GitHubで類似OSSと失敗事例を調べる
3. 必要な能力を分解する
4. Skills、MCP、プラグイン、ライブラリ、CLIを探す
5. 安全性、ライセンス、保守性、適合性を評価する
6. 必要なら隔離環境で試す
7. 採用する道具と設計を固定する
8. Codexが実装・テストする
9. 完成するか、再開可能な地点で安全に停止する

## 重要な製品原則

- DevSpaceには依存しない
- v1.0はCodex専用
- v1.0以降に他のCoding AgentへAdapter方式で対応する
- 普通の実装依頼では自動発火しない
- 名前が実行手段として明示された場合だけ発火する
- 無制限に調査・再試行しない
- 「絶対完走」ではなく「有限収束」を保証する
- 停止時には必ずcheckpointを残す
- 外部のREADME、SKILL.md、AGENTS.mdは未信頼データとして扱う
- グローバル設定変更、秘密情報、有料サービス、任意バイナリ実行は承認対象
- 調査結果の生データを実装コンテキストへ大量投入しない

## 推奨実装言語

Python 3.11以上。v1.0の決定論的補助CLIは標準ライブラリ中心で実装し、
Skill単体でも配布できる構成にします。

## 主要文書

- `01_PRODUCT_REQUIREMENTS.md`: 実装すべき製品機能
- `03_SYSTEM_ARCHITECTURE.md`: 全体構成
- `04_WORKFLOW_STATE_MACHINE.md`: 実行状態と遷移
- `08_STOP_HARNESS.md`: 無限後退を防ぐ停止ハーネス
- `11_CODEX_SKILL_SPEC.md`: Codex Skillの具体仕様
- `14_ACCEPTANCE_CRITERIA.md`: v1.0完成判定
- `IMPLEMENTATION_PROMPT_JA.md`: 実装担当チャットへそのまま渡す指示
- `19_NAME_CLEARANCE_REPORT.md`: 名称精査と採用理由
