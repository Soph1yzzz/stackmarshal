# License Recommendation

Apache License 2.0を推奨する。

理由:
- 商用利用可能
- 改変・配布可能
- 特許許諾が明示
- 企業採用しやすい
- Agent workflow、CLI、AdapterのOSSに向く

実装時には正式なApache-2.0全文を`LICENSE`へ置く。
第三者Skillやテンプレートを同梱する場合は個別ライセンスを確認し、
`THIRD_PARTY_NOTICES.md`を生成する。
