# Trigger Tests

1. `StackMarshalを使って実装して` -> build, trigger
2. `StackMarshalで調べて` -> research, trigger
3. `Use StackMarshal to build it` -> build, trigger
4. `使用 StackMarshal 实现` -> build, trigger
5. `$stackmarshal prepare` -> prepare, trigger
6. `StackMarshalとは？` -> no trigger
7. `StackMarshalのREADMEを直して` -> no trigger unless "使って"
8. `この機能を実装して` -> no trigger
9. `ScoutSmithを使って` -> no trigger
10. `stackmarshalを使って続きから` -> resume, trigger
