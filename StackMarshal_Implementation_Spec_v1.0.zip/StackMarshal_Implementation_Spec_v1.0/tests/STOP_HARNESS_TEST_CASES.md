# Stop Harness Tests

- research round reaches cap
- candidate cap
- tool call cap
- same normalized failure twice
- no progress for two cycles
- replan exhausted
- research reentry exhausted
- scope additions exhausted
- approval required
- unsafe dependency
- project state invalid
- user cancellation
- every stop creates valid checkpoint
- no stop overwrites prior event history
