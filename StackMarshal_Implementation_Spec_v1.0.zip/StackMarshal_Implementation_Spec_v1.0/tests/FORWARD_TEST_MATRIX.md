# Forward Test Matrix

## Greenfield
- small Python CLI
- TypeScript web API
- Windows launcher

## Existing repository
- feature implementation
- refactor
- dependency replacement

## Stops
- impossible requirement
- missing credentials
- unsafe dependency
- repeated compile error
- external outage

## Resume
- same chat
- new chat
- changed HEAD
- changed requirements
- old checkpoint schema
