# 简体中文示例

```text
使用 StackMarshal 实现这个功能。

为当前仓库添加一个跨平台配置管理 CLI。
实现前先调查类似开源项目，并评估可复用的 Skills、MCP、插件、库和 CLI。
```
