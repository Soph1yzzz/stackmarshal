# 0. エグゼクティブ決定

## 正式仮称

**StackMarshal**

タグライン:

> Research the field. Marshal the stack. Ship with limits.

日本語:

> 調べ、揃え、制御し、有限に作り切る。

## 名称決定

候補順位は当初次の通りだった。

1. ScoutSmith
2. AtlasSmith
3. StackMarshal

一次精査の結果:

- ScoutSmith: 同名のGitHubリポジトリ `sumeru-26/ScoutSmith` が存在するため落選
- AtlasSmith: GitHub同名リポジトリと主要パッケージは見当たらないが、
  `atlassmith.com` が登録済みとみられるため落選
- StackMarshal: GitHub、npm、PyPIの完全一致が確認されず、公開検索で完全一致商標も
  見つからなかったため採用

これは法的な商標クリアランスではない。公開前に、USPTO、WIPO、EUIPO、
J-PlatPat等の正式DBと、利用予定国の専門家による最終確認を行うこと。

## 製品定義

StackMarshalはCodexの自律コーディング能力を置き換えない。
Codexがコードを書く前後に、次を有限の予算で統括する。

- Research First
- Capability Mapping
- Cross-Ecosystem Discovery
- Trust Evaluation
- Safe Acquisition
- Architecture Freeze
- Bounded Implementation
- Verification
- Checkpoint / Resume

## v1.0の約束

「どんな依頼でも必ず完成させる」ではない。

次を保証する。

> ユーザーがStackMarshalを明示的に呼んだときだけ起動し、
> 有限予算内で調査・能力獲得・実装・検証を行い、
> COMPLETEまたは再開可能な正式停止状態を必ず返す。

## v1.0以降

Coreの状態形式とポリシーをAgent非依存で定義し、
Codex Adapterを最初の実装とする。

v1.1以降:
- Claude Code
- Gemini CLI
- Cline
- GitHub Copilot
- OpenHands

v2.0候補:
- 複数Agentによる調査・実装・レビューの分業
