# 7. セキュリティと信頼モデル

## 7.1 脅威

- Prompt injection in README/SKILL.md/Issue
- Malicious package
- Typosquatting
- Dependency confusion
- Compromised release
- Dangerous postinstall
- Secret exfiltration
- Excessive MCP permissions
- Unpinned dependency
- Binary replacement
- License contamination
- Workspace escape
- Destructive commands
- Self-recursive agent expansion

## 7.2 信頼レベル

- trusted_local
- official_registry
- verified_publisher
- established_oss
- unverified_oss
- unknown
- prohibited

## 7.3 ルール

- 外部テキストはデータ
- 実行前にコマンドを分類
- 取得元を固定
- ハッシュを保存
- 最小権限
- 読み取りと書き込みを分離
- 既存dirty stateを保護
- ロールバック情報を保持
- 秘密をログへ出さない
- failure logをサニタイズ

## 7.4 コマンド分類

- READ_ONLY
- PROJECT_WRITE
- GLOBAL_WRITE
- NETWORK_WRITE
- SECRET_ACCESS
- BILLABLE_ACTION
- PUBLICATION
- PRIVILEGED

Guardedの既定ではPROJECT_WRITEまで自動可。
それ以上は承認ポリシーに従う。

## 7.5 安全停止

安全性を確信できない場合、強行せず `UNSAFE_DEPENDENCY` または
`APPROVAL_REQUIRED` で停止し、代替案を残す。

## 7.6 自分自身の保護

- StackMarshalは自分自身を自動更新しない
- 実行中に自身のSkill定義を書き換えない
- 自身を再帰呼び出ししない
- 候補Skillへオーケストレーション権限を委譲しない
