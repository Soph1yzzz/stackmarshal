# 13. テスト戦略

## 13.1 単体

- config parse
- schema validation
- state transitions
- budget
- scoring
- failure fingerprint
- progress
- checkpoint
- lock verification
- redaction

## 13.2 統合

- Skill scripts with temporary repository
- GitHub adapter mock
- npm/PyPI adapter mock
- local skill discovery
- MCP config parse
- isolated install receipt
- rollback
- resume

## 13.3 Forward Tests

実際のCodexへSkillを入れ、次を検証。

- 明示起動
- 非起動
- research only
- build success
- budget stop
- repeated failure
- approval stop
- malicious README
- checkpoint resume
- dirty repository

## 13.4 Failure Injection

- network unavailable
- registry 404
- malformed metadata
- hash mismatch
- dependency disappears
- test flakes
- tool command hangs
- repository changes during run
- invalid checkpoint
- duplicate event
- disk full simulation where practical

## 13.5 OS

- Ubuntu latest
- macOS latest
- Windows 11

Windowsをv1.0の必須CI対象にする。

## 13.6 Quality Gates

- ruff
- mypy strict for core
- pytest
- coverage >= 85% core
- JSON Schema tests
- no secret scan findings
- license scan
- release reproducibility
