# 20. リスク登録簿

## R1 CodexのSkill routing変更

対策:
- `$stackmarshal` fallback
- natural-language trigger tests
- host capability detection
- version compatibility matrix

## R2 大手が同機能を統合

対策:
- MarketplaceではなくCapability Map、有限停止、checkpointを核にする
- Adapterとして大手機能を利用可能にする

## R3 Token爆発

対策:
- hard cap
- staged research
- evidence compression
- context size cap
- stop harness

## R4 Supply chain

対策:
- pin
- hash
- provenance
- isolated PoC
- approval
- rollback

## R5 誤発火

対策:
- explicit semantic gate
- anti-trigger tests
- runtime invocation validation

## R6 完了判定の自己欺瞞

対策:
- acceptance criteria
- deterministic status
- test evidence
- unresolved mandatory item => not COMPLETE

## R7 Resume不整合

対策:
- project identity
- HEAD validation
- schema version
- migration
- invalid state stop

## R8 名称衝突

対策:
- release gate
- brand constants
- rename migration
- package fallback name
