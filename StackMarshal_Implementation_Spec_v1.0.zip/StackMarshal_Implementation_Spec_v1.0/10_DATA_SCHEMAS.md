# 10. データ形式

Runtimeの正本はJSON Schemaとする。

## 10.1 Config

`stackmarshal.toml`

- mode
- budget_profile
- autonomy
- research settings
- acquisition policy
- approval policy
- state policy
- language
- adapters

## 10.2 Run State

- schema_version
- run_id
- project
- invocation
- mode
- phase
- status
- timestamps
- budget
- progress
- stop_reason

## 10.3 Candidate

- id
- kind
- source
- metadata
- scores
- risks
- trust
- provenance
- decision
- verification

## 10.4 Capability Map

- capabilities
- dependency edges
- selected acquisition
- verification
- fallback

## 10.5 Task Graph

- task id
- title
- scope
- dependencies
- acceptance links
- attempts
- status
- verification command

## 10.6 Event Log

JSONL append-only。

- seq
- timestamp
- event_type
- phase
- payload_hash
- payload
