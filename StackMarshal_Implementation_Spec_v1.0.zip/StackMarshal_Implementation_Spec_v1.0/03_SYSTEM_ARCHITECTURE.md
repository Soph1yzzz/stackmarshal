# 3. システムアーキテクチャ

## 3.1 構成

StackMarshalは二層構造とする。

### Skill Layer

Codexが読む手順、判断規則、参照資料。

```text
skills/stackmarshal/
├── SKILL.md
├── agents/openai.yaml
├── references/
├── scripts/
└── assets/templates/
```

### Deterministic Core

状態、予算、採点、停止、checkpointを決定論的に管理するPythonモジュール。

```text
src/stackmarshal/
├── cli.py
├── config.py
├── state.py
├── budget.py
├── progress.py
├── failure.py
├── scoring.py
├── checkpoint.py
├── validation.py
├── adapters/
└── models/
```

## 3.2 責務分離

LLMが担当:

- 意図理解
- 要件抽出
- 調査クエリ生成
- 設計比較
- 技術判断
- 実装
- 根本原因分析

Deterministic Coreが担当:

- 状態遷移
- 上限カウント
- JSON Schema検証
- 候補スコア計算
- failure fingerprint
- 進捗履歴
- stop decision
- checkpoint生成
- lockfile整合性
- resume対象選定

## 3.3 Adapter境界

```python
class DiscoveryAdapter(Protocol):
    def search(self, query, limits): ...
    def fetch_metadata(self, identifier): ...

class AcquisitionAdapter(Protocol):
    def inspect(self, candidate): ...
    def install_isolated(self, candidate, sandbox): ...
    def install_project(self, candidate, target): ...
    def rollback(self, receipt): ...

class AgentAdapter(Protocol):
    def detect_environment(self): ...
    def list_native_capabilities(self): ...
    def execute_task(self, task): ...
    def verify(self, scope): ...
```

v1.0ではCodex Adapterのみ実装するが、CoreはAgent名をハードコードしない。

## 3.4 主要Adapter

- GitHub Plugin Adapter
- GitHub CLI Adapter
- Web Search Adapter
- Local Skills Adapter
- Codex Plugin Adapter
- MCP Config Adapter
- npm Registry Adapter
- PyPI Adapter
- crates.io Adapter
- Go Module Adapter
- Local Package Manager Adapter
- Codex Execution Adapter

## 3.5 ファイル配置

```text
.stackmarshal/
├── config.toml
├── project/
│   ├── requirements.json
│   ├── acceptance.json
│   ├── capability-map.json
│   ├── architecture.md
│   ├── decisions/
│   └── locks/
└── runs/
    └── <run-id>/
        ├── run.json
        ├── budget.json
        ├── events.jsonl
        ├── candidates.json
        ├── task-state.json
        ├── failures.json
        ├── checkpoint.md
        └── final-report.md
```

`project/`は原則コミット可能。
`runs/`は既定でgitignoreし、最終checkpointだけ保存可能にする。

## 3.6 依存方針

v1.0 Runtime:
- Python 3.11+
- 標準ライブラリ中心
- 外部必須依存は原則ゼロ

Development:
- pytest
- ruff
- mypy
- coverage
- build
- twine

設定はTOML、状態はJSON、ログはJSONL、説明はMarkdownとする。
