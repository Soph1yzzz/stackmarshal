# 18. v1.0以降の他Agent対応

## v1.0

Codex専用。
Core schemaとpolicyはAgent非依存。

## v1.1

AgentAdapter interfaceを安定化し、Codex implementationをAdapterへ完全分離。

## v1.2+

候補:

- Claude Code
- Gemini CLI
- Cline
- GitHub Copilot
- OpenHands

対応順はGitHub Issue投票、コントリビューター、実需要で決める。

## v2.0

Agent-neutral protocol。

例:
- Research: Codex
- Implementation: Claude Code
- Review: Codex
- E2E: OpenHands

ただしv1.0でmulti-agent orchestrationを実装しない。
